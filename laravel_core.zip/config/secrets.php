<?php

return [
    'admins' => [
        'admin1@example.com' => [
            'password' => "$2y$12$9X/f5Cj/H3jk5hUaJQ.WP.6jR0EUG1WbqzEx.N5Gpu320XF7fuA1S", // bcrypt hash
            'name' => 'Admin One',
        ],
        'admin2@example.com' => [
            'password' => "$2y$12$3.dxOg3mg4RtLAj1AX4XG.OYoXIYrQEZ6Eg1s.odIROy093RmvEF6", // bcrypt hash
            'name' => 'Admin Two',
        ],
    ],
];