

<?php $__env->startSection('title', 'Contributions'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="dashboard-title mb-4 animate__animated animate__fadeIn">Your Contributions</h1>

        <div class="card shadow-lg border-0 animate__animated animate__slideIn animate__delay-1s">
            <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center py-4">
                <h4 class="mb-0"><i class="bi bi-wallet2 me-2"></i>Contribution List</h4>
                <div>
                    <a href="<?php echo e(route('user.installments.create')); ?>" class="btn btn-success btn-sm me-2">
                        <i class="bi bi-plus-circle me-1"></i> Add Contribution
                    </a>
                    <a href="<?php echo e(route('user.dashboard')); ?>" class="btn btn-outline-light btn-sm">
                        <i class="bi bi-arrow-left me-2"></i> Back to Dashboard
                    </a>
                </div>
            </div>
            <div class="card-body form-container">
                <?php if(session('success')): ?>
                    <div class="alert alert-success animate__animated animate__bounceIn">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger animate__animated animate__shakeX">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if($installments->isEmpty()): ?>
                    <p class="text-muted text-center py-4">No contributions recorded. Click "Add Contribution" to start!</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr class="bg-light">
                                    <th>Amount (BDT)</th>
                                    <th>Month</th>
                                    <th>Year</th>
                                    <th>Payment Date</th>
                                    <th>Method</th>
                                    <th>Transaction ID</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(number_format($installment->amount, 2)); ?></td>
                                        <td><?php echo e($installment->payment_month); ?></td>
                                        <td><?php echo e($installment->payment_year); ?></td>
                                        <td><?php echo e($installment->payment_date ? $installment->payment_date->format('M d, Y') : '-'); ?></td>
                                        <td><?php echo e($installment->payment_method ?? '-'); ?></td>
                                        <td><?php echo e($installment->transaction_id ?? '-'); ?></td>
                                        <td>
                                            <span class="badge <?php echo e($installment->status === 'approved' ? 'bg-success' : 'bg-warning'); ?>">
                                                <?php echo e(ucfirst($installment->status)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('user.installments.edit', ['installment' => $installment->id])); ?>" class="btn btn-sm btn-primary shadow-sm">
                                                <i class="bi bi-pencil me-1"></i> Update
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .table th, .table td {
            vertical-align: middle;
            padding: 12px;
        }
        .table-hover tbody tr:hover {
            background: #f1f5f9;
        }
        .dark-mode .table-hover tbody tr:hover {
            background: #4b5563;
        }
        .badge {
            font-size: 0.9rem;
            padding: 6px 12px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.table').addClass('animate__animated animate__fadeIn animate__delay-2s');
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp4\htdocs\myapp_ live\resources\views\user\installments\index.blade.php ENDPATH**/ ?>