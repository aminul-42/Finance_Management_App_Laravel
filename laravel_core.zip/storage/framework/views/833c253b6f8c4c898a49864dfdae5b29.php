

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="dashboard-title mb-4 animate__animated animate__fadeIn">Admin Dashboard</h1>

        <div class="user-info mb-4 animate__animated animate__slideInRight p-3 rounded-3">
            <div class="d-flex align-items-center gap-3">
                <img src="<?php echo e(Auth::user()->profile_picture ? asset('storage/' . Auth::user()->profile_picture) : asset('storage/default-avatar.png')); ?>"
                     alt="Profile Picture" class="user-avatar shadow-sm animate__animated animate__zoomIn">
                <div>
                    <span class="fw-bold fs-4">Welcome, <?php echo e(Auth::user()->name); ?></span>
                    <p class="text-muted mb-0">Manage your contributions and profile.</p>
                </div>
               
            </div>
        </div>

        
 <!-- Financial Overview -->
 <div class="card mb-4 animate__animated animate__slideIn animate__delay-1s">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-pie-chart-fill me-2"></i>Financial Overview</h5>
            </div>
            <div class="card-body">
                <div class="row g-4 text-center">
                    <div class="col-md-4">
                        <div class="financial-card">
                            <h6 class="text-muted">Total Organization Balance (Contributions + Profits)</h6>
                            <h4 class="text-primary fw-bold"><?php echo e(number_format($organizationBalance, 2)); ?> BDT</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="financial-card">
                            <h6 class="text-muted">Total Contributions</h6>
                            <h4 class="text-success fw-bold"><?php echo e(number_format($totalContributions, 2)); ?> BDT</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="financial-card">
                            <h6 class="text-muted">Total Profits</h6>
                            <h4 class="text-info fw-bold"><?php echo e(number_format($totalProfits, 2)); ?> BDT</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pending Contributions -->
        <div class="card animate__animated animate__slideInUp animate__delay-2s">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-hourglass-split me-2"></i>Pending Contributions</h5>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success animate__animated animate__bounceIn">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger animate__animated animate__shakeX">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if($pendingContributions->isEmpty()): ?>
                    <p class="text-muted text-center py-4">No pending contributions.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr class="bg-light">
                                    <th>User</th>
                                    <th>Amount (BDT)</th>
                                    <th>Month</th>
                                    <th>Year</th>
                                    <th>Payment Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pendingContributions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contribution): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($contribution->user->name); ?></td>
                                        <td><?php echo e(number_format($contribution->amount, 2)); ?></td>
                                        <td><?php echo e($contribution->payment_month); ?></td>
                                        <td><?php echo e($contribution->payment_year); ?></td>
                                        <td><?php echo e($contribution->payment_date ? $contribution->payment_date->format('M d, Y') : '-'); ?>

                                        </td>
                                        <td>
                                            <span class="badge bg-warning"><?php echo e(ucfirst($contribution->status)); ?></span>
                                        </td>
                                        <td>
                                            <form action="<?php echo e(route('admin.contributions.approve', $contribution)); ?>" method="POST"
                                                style="display: inline;">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm btn-success me-2">
                                                    <i class="bi bi-check-circle"></i> Approve
                                                </button>
                                            </form>
                                            <form action="<?php echo e(route('admin.contributions.reject', $contribution)); ?>" method="POST"
                                                style="display: inline;"
                                                onsubmit="return confirm('Are you sure you want to reject this contribution?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="bi bi-x-circle"></i> Reject
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>


       

        

        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .user-info {
            background: linear-gradient(90deg, rgba(79, 70, 229, 0.15), rgba(168, 85, 247, 0.15));
            transition: background 0.3s ease;
        }
        .dark-mode .user-info {
            background: linear-gradient(90deg, rgba(79, 70, 229, 0.3), rgba(168, 85, 247, 0.3));
        }
        .user-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid #ffffff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .table th, .table td {
            vertical-align: middle;
            padding: 12px;
        }
        .table-hover tbody tr:hover {
            background: #f1f5f9;
        }
        .dark-mode .table-hover tbody tr:hover {
            background: #4b5563;
        }
        .badge {
            font-size: 0.9rem;
            padding: 6px 12px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('.table').addClass('animate__animated animate__fadeIn animate__delay-4s');
        });
    </script>
<?php $__env->stopSection(); ?>












<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp4\htdocs\myapp_ live\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>