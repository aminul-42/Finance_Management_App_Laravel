

<?php $__env->startSection('title', 'Add Contribution'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h1 class="dashboard-title mb-4 animate__animated animate__fadeIn">Add New Contribution</h1>

        <div class="card shadow-lg border-0 animate__animated animate__zoomIn">
            <div class="card-header bg-primary text-white text-center py-4">
                <h4 class="mb-0"><i class="bi bi-wallet2 me-2"></i>Create Contribution</h4>
            </div>
            <div class="card-body form-container">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger animate__animated animate__shakeX">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('user.installments.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row g-4">
                        <div class="col-md-6">
                            <label for="amount" class="form-label fw-bold">Amount (BDT)</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-currency-exchange"></i></span>
                                <input type="number" class="form-control professional-input shadow-sm" id="amount" name="amount"
                                       value="<?php echo e(old('amount')); ?>" step="0.01" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="payment_month" class="form-label fw-bold">Payment Month</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-calendar-month"></i></span>
                                <select class="form-control professional-input shadow-sm" id="payment_month" name="payment_month" required>
                                    <option value="" disabled <?php echo e(old('payment_month') ? '' : 'selected'); ?>>Select Month</option>
                                    <?php $__currentLoopData = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($month); ?>" <?php echo e(old('payment_month') === $month ? 'selected' : ''); ?>><?php echo e($month); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="payment_year" class="form-label fw-bold">Payment Year</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-calendar-year"></i></span>
                                <input type="number" class="form-control professional-input shadow-sm" id="payment_year" name="payment_year"
                                       value="<?php echo e(old('payment_year', now()->year)); ?>" min="2000" max="2100" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="payment_date" class="form-label fw-bold">Payment Date</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-calendar"></i></span>
                                <input type="date" class="form-control professional-input shadow-sm" id="payment_date" name="payment_date"
                                       value="<?php echo e(old('payment_date', now()->format('Y-m-d'))); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="payment_method" class="form-label fw-bold">Payment Method</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-credit-card"></i></span>
                                <select class="form-control professional-input shadow-sm" id="payment_method" name="payment_method" required>
                                    <option value="" disabled <?php echo e(old('payment_method') ? '' : 'selected'); ?>>Select Method</option>
                                    <option value="bKash" <?php echo e(old('payment_method') === 'bKash' ? 'selected' : ''); ?>>bKash</option>
                                    <option value="Nagad" <?php echo e(old('payment_method') === 'Nagad' ? 'selected' : ''); ?>>Nagad</option>
                                    <option value="Bank Transfer" <?php echo e(old('payment_method') === 'Bank Transfer' ? 'selected' : ''); ?>>Bank Transfer</option>
                                    <option value="Cash" <?php echo e(old('payment_method') === 'Cash' ? 'selected' : ''); ?>>Cash</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label for="transaction_id" class="form-label fw-bold">Transaction ID (Optional)</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light"><i class="bi bi-receipt"></i></span>
                                <input type="text" class="form-control professional-input shadow-sm" id="transaction_id" name="transaction_id"
                                       value="<?php echo e(old('transaction_id')); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="mt-5 text-center">
                        <button type="submit" class="btn btn-success w-50 py-3 fw-bold shadow-sm">
                            <i class="bi bi-check-circle me-2"></i>Add Contribution
                        </button>
                    </div>
                </form>
                <div class="mt-3 text-center">
                    <a href="<?php echo e(route('user.installments.index')); ?>" class="btn btn-outline-primary px-4">
                        <i class="bi bi-arrow-left me-2"></i>Back to Contributions
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
    <style>
        .form-control:focus, .form-select:focus {
            border-color: #4f46e5;
            box-shadow: 0 0 10px rgba(79, 70, 229, 0.3);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp4\htdocs\myapp_ live\resources\views\user\installments\create.blade.php ENDPATH**/ ?>