

<?php $__env->startSection('title', 'contribution Index'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
        <h1 class="my-4 animate__animated animate__fadeIn">All Contributions</h1>

        <!-- Filter Form -->
        <div class="filter-form mb-4 animate__animated animate__fadeIn">
            <form action="<?php echo e(route('admin.contributions.index')); ?>" method="GET" class="row g-3">
                <div class="col-md-4">
                    <label for="month" class="form-label">Month</label>
                    <select name="month" id="month" class="form-control">
                        <option value="">All Months</option>
                        <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($m); ?>" <?php echo e($month === $m ? 'selected' : ''); ?>><?php echo e($m); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="year" class="form-label">Year</label>
                    <select name="year" id="year" class="form-control">
                        <option value="">All Years</option>
                        <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($y); ?>" <?php echo e($year == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4 align-self-end">
                    <button type="submit" class="btn btn-primary w-100">Filter</button>
                </div>
            </form>
        </div>

        <div class="card animate__animated animate__slideInUp">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-wallet2 me-2"></i>Contribution Records</h5>
            </div>
            <div class="card-body">
                <?php if(session('success')): ?>
                    <div class="alert alert-success animate__animated animate__bounceIn">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger animate__animated animate__shakeX">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php if($installments->isEmpty()): ?>
                    <p class="text-muted text-center py-4">No contributions recorded.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr class="bg-light">
                                    <th>User</th>
                                    <th>Amount (BDT)</th>
                                    <th>Month</th>
                                    <th>Year</th>
                                    <th>Payment Date</th>
                                    <th>Method</th>
                                    <th>Transaction ID</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $installments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($installment->user->name); ?></td>
                                        <td><?php echo e(number_format($installment->amount, 2)); ?></td>
                                        <td><?php echo e($installment->payment_month); ?></td>
                                        <td><?php echo e($installment->payment_year); ?></td>
                                        <td><?php echo e($installment->payment_date ? $installment->payment_date->format('M d, Y') : '-'); ?></td>
                                        <td><?php echo e($installment->payment_method ?? '-'); ?></td>
                                        <td><?php echo e($installment->transaction_id ?? '-'); ?></td>
                                        <td>
                                            <span class="badge <?php echo e($installment->status === 'approved' ? 'bg-success' : 'bg-warning'); ?>">
                                                <?php echo e(ucfirst($installment->status)); ?>

                                            </span>
                                        </td>
                                        <td>
                                            <?php if($installment->status === 'pending'): ?>
                                                <form action="<?php echo e(route('admin.contributions.approve', $installment)); ?>" method="POST" style="display: inline;">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="btn btn-sm btn-success">
                                                        <i class="bi bi-check-circle"></i> Approve
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>













<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp4\htdocs\myapp_ live\resources\views\admin\contributions\index.blade.php ENDPATH**/ ?>